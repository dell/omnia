# Copyright 2026 Dell Inc. or its subsidiaries. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
run_playbook — subprocess-based playbook execution with live streaming.

Runs ``ansible-playbook`` directly via subprocess on the target host
(bare-metal, no container exec) with live output streaming.  For remote
hosts the command is wrapped in SSH.

Output is read line-by-line in the calling thread — **no reader threads
are spawned**.  A lightweight ``threading.Timer`` enforces the timeout.

Usage::

    result = run_playbook(tag="prepare")
    assert result["success"], result["error"]
"""

import os
import re
import shlex
import shutil
import signal
import subprocess
import threading
import time
from typing import Any, Dict, List, Optional, Tuple

from .host_func import (
    load_test_config,
    load_test_credentials,
    is_local_execution,
)
from .formatting_func import TestLogger, Colors, Symbols
from .process_security import (
    descriptor_tuple,
    scrubbed_subprocess_environment,
    sshpass_pipe,
)
from ._ssh_options import (
    parse_ssh_options,
    validate_ssh_destination,
    validate_ssh_port,
)
from ..vars.common_vars import get_setting, get_module_root
from ..messages.runner_msgs import (
    RUNNER_LOG_MSGS,
    RUNNER_ASSERT_MSGS,
)

_ANSI_RE = re.compile(
    r"\x1b\[[0-9;]*[a-zA-Z]"
    r"|\x1b\][^\x07]*\x07"
    r"|\x1b\([A-Z]"
    r"|[\x00-\x08\x0e-\x1f]"
    r"|\r"
)


# =====================================================================
# PUBLIC API
# =====================================================================

def run_playbook(
    playbook: Optional[str] = None,
    tag=None,
    extra_vars: Optional[Dict[str, str]] = None,
    verbosity: Optional[int] = None,
    timeout: Optional[int] = None,
    limit: Optional[str] = None,
    playbook_workdir: Optional[str] = None,
) -> Dict[str, Any]:
    """Run an ansible-playbook with live output streaming.

    Builds the ``ansible-playbook`` command, wraps it in SSH for remote
    targets, and streams output line-by-line in the calling thread.

    Args:
        playbook: Playbook filename (e.g. ``image_build_manager.yml``).
        tag: Ansible tag(s). Accepts a single string
             (``"prepare"``), a list (``["prepare", "build"]``),
             or ``None`` to run without ``--tags``.
        extra_vars: Extra ``-e key=value`` pairs.
        verbosity: Ansible verbosity 0-4.
        timeout: Max seconds to wait.
        limit: Ansible ``--limit`` pattern.
        playbook_workdir: Subdirectory under ``clone_path`` where
                          the playbook lives.

    Returns:
        Dict with keys: success, rc, output, duration, error, playbook.
    """
    if not isinstance(playbook, str) or not playbook:
        return _fail(
            "unknown", 0.0,
            "'playbook' argument is required",
        )
    if not isinstance(playbook_workdir, str) or not playbook_workdir:
        return _fail(
            playbook, 0.0,
            "'playbook_workdir' argument is required",
        )

    try:
        config = load_test_config()
        credentials = load_test_credentials()
        local_mode = is_local_execution()
    except (OSError, RuntimeError, ValueError) as exc:
        return _fail(playbook, 0.0, str(exc))

    v = verbosity if verbosity is not None else get_setting(
        "default_verbosity", 1,
    )
    t = timeout if timeout is not None else get_setting(
        "default_timeout", 7200,
    )
    if not isinstance(v, int) or isinstance(v, bool) or v not in range(5):
        return _fail(playbook, 0.0, "verbosity must be an integer from 0 to 4")
    if not isinstance(t, int) or isinstance(t, bool) or t <= 0:
        return _fail(playbook, 0.0, "timeout must be a positive integer")

    if local_mode:
        repository_root = get_setting("repository_root")
        if not repository_root:
            repository_root = os.path.dirname(
                os.path.dirname(get_module_root())
            )
        workdir = (
            playbook_workdir if os.path.isabs(playbook_workdir)
            else os.path.join(repository_root, playbook_workdir)
        )
        if not os.path.isdir(workdir):
            return _fail(
                playbook, 0.0,
                f"Playbook working directory not found: {workdir}",
            )
    else:
        # Remote: use clone_path on the target server
        clone_path = config.get("clone_path", "")
        if not clone_path:
            return _fail(
                playbook, 0.0,
                "'clone_path' must be set in test_config.yml for remote execution",
            )
        workdir = os.path.join(clone_path, playbook_workdir)

    logger_name = get_setting("runner_logger_name", "playbook_runner")  # safe default
    log = TestLogger(logger_name)

    oim_auth = credentials.get("oim_password", "")
    if not local_mode and oim_auth and not shutil.which("sshpass"):
        return _fail(
            playbook, 0.0,
            RUNNER_ASSERT_MSGS["sshpass_missing"],
        )

    # venv_path: derived from OMNIA_VENV_PATH in /etc/omnia/omnia.env
    # on the target (or local) host — never from test_config.yml.
    env_file = get_setting("env_file", "/etc/omnia/omnia.env")
    venv_env_var = get_setting("venv_env_var", "OMNIA_VENV_PATH")

    try:
        ansible_cmd = _build_ansible_cmd(
            playbook, workdir, v, extra_vars, tag, limit,
            env_file, venv_env_var,
        )
    except (TypeError, ValueError) as exc:
        return _fail(playbook, 0.0, str(exc))

    if local_mode:
        cmd = ansible_cmd
        log.check(RUNNER_LOG_MSGS["connecting_local"])
    else:
        host = config["oim_server_ip"]
        port = config.get("oim_ssh_port", 22)
        log.check(RUNNER_LOG_MSGS["connecting_remote"].format(
            host=host, port=port,
        ))

    tag_str = ",".join(tag) if isinstance(tag, list) else (tag or "all")
    log.check(RUNNER_LOG_MSGS["starting_playbook"].format(
        playbook=playbook, tag=tag_str,
    ))
    log.check(RUNNER_LOG_MSGS["streaming_output"])

    if local_mode:
        return _stream_cmd(
            cmd, playbook, t, tag, config, playbook_workdir,
        )

    try:
        with sshpass_pipe(oim_auth) as auth_fd:
            cmd = _wrap_ssh(
                ansible_cmd, config, credentials, auth_fd=auth_fd,
            )
            return _stream_cmd(
                cmd,
                playbook,
                t,
                tag,
                config,
                playbook_workdir,
                pass_fds=descriptor_tuple(auth_fd),
            )
    except (OSError, ValueError) as exc:
        return _fail(playbook, 0.0, str(exc))


# =====================================================================
# COMMAND BUILDERS
# =====================================================================

def _build_ansible_cmd(
    playbook: str,
    workdir: str,
    verbosity: int,
    extra_vars: Optional[Dict[str, str]],
    tag,
    limit: Optional[str],
    env_file: str = "/etc/omnia/omnia.env",
    venv_env_var: str = "OMNIA_VENV_PATH",
) -> str:
    """Build the ``ansible-playbook`` command string.

    The venv path is sourced from the ``OMNIA_VENV_PATH`` env var
    defined in ``/etc/omnia/omnia.env`` on the target host.  If the
    env var is unset the command falls through without activation.
    """
    if not isinstance(env_file, str) or not env_file:
        raise ValueError("env_file must be a non-empty path")
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", venv_env_var):
        raise ValueError("venv_env_var must be a valid environment name")
    if tag is not None:
        tag_values = tag if isinstance(tag, list) else [tag]
        if not tag_values or not all(
            isinstance(value, str) and value for value in tag_values
        ):
            raise ValueError(
                "tag must be a string or a non-empty list of strings"
            )
    if limit is not None and (not isinstance(limit, str) or not limit):
        raise ValueError("limit must be a non-empty string")
    if extra_vars is not None and not isinstance(extra_vars, dict):
        raise ValueError("extra_vars must be a mapping")

    v_flag = f" -{'v' * verbosity}" if verbosity > 0 else ""

    parts = [
        # Source omnia.env and activate venv from env var
        f"set -a && . {shlex.quote(env_file)} && set +a &&",
        f'if [ -n "${{{venv_env_var}}}" ]; then'
        f' source "${{{venv_env_var}}}/bin/activate"; fi &&',
        f"cd {shlex.quote(workdir)} &&",
        f"COLUMNS={get_setting('line_width', 160)}"
        f" ansible-playbook {shlex.quote(playbook)}{v_flag}",
    ]

    if extra_vars:
        for key, val in extra_vars.items():
            if not isinstance(key, str) or not re.fullmatch(
                r"[A-Za-z_][A-Za-z0-9_.-]*", key,
            ):
                raise ValueError(
                    f"Invalid Ansible extra variable name: {key!r}"
                )
            parts.append(
                f"--extra-vars {shlex.quote(f'{key}={val}')}",
            )
    if tag:
        tag_str = ",".join(tag) if isinstance(tag, list) else tag
        parts.append(f"--tags {shlex.quote(tag_str)}")
    if limit:
        parts.append(f"--limit {shlex.quote(limit)}")

    return " ".join(parts)


def _wrap_ssh(
    cmd: str,
    config: Dict,
    credentials: Dict,
    auth_fd: Optional[int] = None,
) -> str:
    """Wrap a command in SSH for remote execution."""
    host, user = validate_ssh_destination(
        config["oim_server_ip"],
        config.get("oim_ssh_user", "root"),
    )
    port = str(validate_ssh_port(config.get("oim_ssh_port", 22)))
    oim_auth = credentials.get("oim_password", "")

    if oim_auth:
        if auth_fd is None:
            raise ValueError(
                "An authentication descriptor is required for sshpass"
            )
        parts = [
            "sshpass", "-d", str(auth_fd),
            "ssh", "-T",
        ]
    else:
        parts = ["ssh", "-T"]

    parts.extend(parse_ssh_options(get_setting("ssh_options_list", [
        "-o", "StrictHostKeyChecking=accept-new",
        "-o", "LogLevel=ERROR",
    ])))
    parts.extend([
        "-p", port,
        "--",
        f"{user}@{host}",
        cmd,
    ])
    return shlex.join(parts)


# =====================================================================
# EXECUTION — single path for local and remote
# =====================================================================

def _stream_cmd(
    cmd: str,
    playbook: str,
    timeout: int,
    tag: Optional[str],
    config: Dict,
    pb_workdir: str = "src",
    pass_fds: Tuple[int, ...] = (),
) -> Dict[str, Any]:
    """Execute *cmd* via subprocess, streaming output line-by-line.

    Output is read in the calling thread (no spawned reader threads).
    A lightweight ``threading.Timer`` enforces the timeout by killing
    the process group if the deadline is exceeded.
    """
    pipe_prefix = (
        f"    {Colors.GRAY}{Symbols.PIPE}{Colors.RESET} "
    )
    output_lines: List[str] = []
    start = time.time()
    timed_out = False
    process = None
    watchdog = None

    try:
        process = subprocess.Popen(
            ["bash", "-c", cmd],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            bufsize=1,
            text=True,
            start_new_session=True,
            pass_fds=pass_fds,
            env=scrubbed_subprocess_environment(),
        )

        # Lightweight timeout watchdog (no reader threads)
        def _on_timeout():
            nonlocal timed_out
            timed_out = True
            _kill_process_group(process)

        watchdog = threading.Timer(timeout, _on_timeout)
        watchdog.daemon = True
        watchdog.start()

        # Read output line-by-line in the calling thread
        try:
            for raw_line in process.stdout:
                clean = _ANSI_RE.sub(
                    "", raw_line,
                ).rstrip("\n\r ")
                output_lines.append(clean)
                if not clean:
                    print(pipe_prefix, flush=True)
                else:
                    _print_wrapped(clean, pipe_prefix)
        except (ValueError, OSError):
            pass

        rc = process.wait()
        watchdog.cancel()

        duration = time.time() - start

        if timed_out:
            return _fail(
                playbook, duration,
                RUNNER_ASSERT_MSGS["playbook_timeout"].format(
                    playbook=playbook, timeout=timeout,
                ),
                rc=-1, output="\n".join(output_lines),
            )

        if rc == 0:
            return _ok(playbook, rc, output_lines, duration)

        clone_path = config.get("clone_path", "")
        return _fail(
            playbook, duration,
            RUNNER_ASSERT_MSGS["playbook_failed"].format(
                playbook=playbook,
                tag=(",".join(tag) if isinstance(tag, list) else tag) or "all",
                rc=rc, duration=duration,
                log_path=config.get("shared_path", "") + "/log/",
                workdir=os.path.join(clone_path, pb_workdir),
            ),
            rc=rc, output="\n".join(output_lines),
        )

    except KeyboardInterrupt:
        duration = time.time() - start
        _kill_process_group(process)
        print(
            f"\n{pipe_prefix}"
            f"{Colors.BRIGHT_YELLOW}Cancelled by user"
            f"{Colors.RESET}",
            flush=True,
        )
        return _fail(
            playbook, duration,
            RUNNER_ASSERT_MSGS["cancelled"],
            rc=-2, output="\n".join(output_lines),
        )

    except subprocess.TimeoutExpired:
        duration = time.time() - start
        _kill_process_group(process)
        return _fail(
            playbook, duration,
            RUNNER_ASSERT_MSGS["playbook_timeout"].format(
                playbook=playbook, timeout=timeout,
            ),
            rc=-1, output="\n".join(output_lines),
        )

    except OSError as exc:
        duration = time.time() - start
        _kill_process_group(process)
        return _fail(
            playbook, duration,
            RUNNER_ASSERT_MSGS["os_error"] + f": {exc}",
            rc=-1, output="\n".join(output_lines),
        )

    finally:
        if watchdog is not None:
            watchdog.cancel()
        _cleanup_process(process)


# =====================================================================
# SHARED HELPERS
# =====================================================================

def _print_wrapped(line: str, prefix: str) -> None:
    """Print a line, wrapping at configured line_width."""
    width = get_setting("line_width", 160)  # 160 safe default
    while line:
        chunk = line[:width]
        line = line[width:]
        print(f"{prefix}{chunk}", flush=True)


def _ok(
    playbook: str,
    rc: int,
    output_lines: List[str],
    duration: float,
) -> Dict[str, Any]:
    """Build a success result dict."""
    return {
        "success": True,
        "rc": rc,
        "output": "\n".join(output_lines),
        "duration": duration,
        "error": None,
        "playbook": playbook,
    }


def _fail(
    playbook: str,
    duration: float,
    error: str,
    rc: int = -1,
    output: str = "",
) -> Dict[str, Any]:
    """Build a failure result dict."""
    return {
        "success": False,
        "rc": rc,
        "output": output,
        "duration": duration,
        "error": error,
        "playbook": playbook,
    }


def _kill_process_group(process: Any) -> None:
    """Kill the entire process group."""
    if process is None:
        return
    try:
        pgid = os.getpgid(process.pid)
        os.killpg(pgid, signal.SIGKILL)
    except OSError:
        pass
    try:
        process.kill()
    except OSError:
        pass
    try:
        process.wait(timeout=3)
    except (subprocess.TimeoutExpired, OSError):
        pass


def _cleanup_process(process: Any) -> None:
    """Close all open streams on a process."""
    if process is None:
        return
    for stream in (process.stdin, process.stdout, process.stderr):
        if stream and not stream.closed:
            try:
                stream.close()
            except OSError:
                pass
