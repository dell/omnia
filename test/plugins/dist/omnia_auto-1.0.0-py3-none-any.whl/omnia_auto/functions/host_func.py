# Copyright 2026 Dell Inc. or its subsidiaries. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Testinfra host, configuration, and credential utilities.

Handles:
- Config YAML loading
- Credentials loading with Ansible Vault encryption
- Testinfra host connection (local or remote SSH)
- Local vs remote execution detection
- Remote environment variable reading
- Remote directory management
- Domain input path resolution
"""

import atexit
import os
import shutil
import shlex
import subprocess
import tempfile
from typing import Any, Dict, List, Optional, Tuple

import yaml
import testinfra

from ..vars.common_vars import get_module_root, get_setting
from ..vars.credential_vars import VAULT_FILE_MODE, VAULT_HEADER
from .formatting_func import log
from .process_security import (
    atomic_sensitive_output,
    exclusive_sensitive_text,
    open_sensitive_text,
    protect_sensitive_file as _protect_sensitive_file,
    run_vault_decrypt,
    run_vault_encrypt,
    sensitive_file_descriptor,
)


_TESTINFRA_INVENTORY_DIRS: List[str] = []


@atexit.register
def _cleanup_testinfra_inventory_dirs() -> None:
    """Remove protected temporary inventories when the runner exits."""
    while _TESTINFRA_INVENTORY_DIRS:
        shutil.rmtree(
            _TESTINFRA_INVENTORY_DIRS.pop(), ignore_errors=True,
        )


def _write_testinfra_inventory(inventory: Dict[str, Any]) -> str:
    """Write an Ansible YAML inventory in a private temporary directory."""
    inventory_dir = tempfile.mkdtemp(prefix="omnia_auto_testinfra_")
    os.chmod(inventory_dir, 0o700)
    inventory_path = os.path.join(inventory_dir, "inventory.yml")
    try:
        with exclusive_sensitive_text(
            inventory_path, VAULT_FILE_MODE,
        ) as inv_fh:
            yaml.safe_dump(inventory, inv_fh, sort_keys=False)
    except (OSError, ValueError, yaml.YAMLError):
        shutil.rmtree(inventory_dir, ignore_errors=True)
        raise
    _TESTINFRA_INVENTORY_DIRS.append(inventory_dir)
    return inventory_path


# =============================================================================
# CONFIG LOADING
# =============================================================================

def _resolve_config_path(config_path: Optional[str] = None) -> str:
    """Resolve the config file path.

    Args:
        config_path: Explicit path.  When ``None``, built from
                     ``module_root`` + ``config_file`` setting.

    Raises:
        RuntimeError: If neither param nor setting is available.
    """
    if config_path:
        return config_path
    config_file = get_setting("config_file")
    if not config_file:
        raise RuntimeError(
            "config_file not configured. "
            "Pass config_path= or call configure(config_file=...)."
        )
    return os.path.join(get_module_root(), config_file)


def _resolve_credentials_paths(
    creds_path: Optional[str] = None,
    key_path: Optional[str] = None,
) -> Tuple[str, str]:
    """Resolve credentials file and key file paths.

    Args:
        creds_path: Explicit credentials file path.
        key_path: Explicit vault key file path.

    Raises:
        RuntimeError: If neither param nor setting is available.
    """
    root = get_module_root()
    if not creds_path:
        creds_file = get_setting("credentials_file")
        if not creds_file:
            raise RuntimeError(
                "credentials_file not configured. "
                "Pass creds_path= or call configure(credentials_file=...)."
            )
        creds_path = os.path.join(root, creds_file)
    if not key_path:
        key_file = get_setting("credentials_key")
        if not key_file:
            raise RuntimeError(
                "credentials_key not configured. "
                "Pass key_path= or call configure(credentials_key=...)."
            )
        key_path = os.path.join(root, key_file)
    return creds_path, key_path


def load_test_config(config_path: Optional[str] = None) -> Dict[str, Any]:
    """Load test configuration from a YAML file.

    Args:
        config_path: Explicit file path.  When ``None``, resolved
                     from ``configure(config_file=...)``.

    Returns:
        Dict containing the configuration, or empty dict if not found.
    """
    path = _resolve_config_path(config_path)
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as cfg_fh:
            return yaml.safe_load(cfg_fh) or {}
    return {}


# =============================================================================
# VAULT ENCRYPTION
# =============================================================================

def _is_vault_encrypted(file_path: str) -> bool:
    """Check if file is ansible-vault encrypted."""
    if not os.path.lexists(file_path):
        return False
    with open_sensitive_text(
        file_path, VAULT_FILE_MODE,
    ) as file_stream:
        first_line = file_stream.readline().strip()
    return first_line.startswith(VAULT_HEADER)


def _create_vault_key(key_path: str) -> None:
    """Create a new vault key file with a random 32-char token."""
    import secrets
    key = secrets.token_urlsafe(32)[:32]
    with exclusive_sensitive_text(key_path, VAULT_FILE_MODE) as f:
        f.write(key)


def _decrypt_vault_file(config_path: str, key_path: str) -> Dict:
    """Decrypt ansible-vault encrypted file and return as dict."""
    try:
        with sensitive_file_descriptor(
            config_path, VAULT_FILE_MODE,
        ) as config_fd, sensitive_file_descriptor(
            key_path, VAULT_FILE_MODE,
        ) as key_fd:
            plaintext = run_vault_decrypt(
                config_fd,
                key_fd,
                timeout=30,
            )
        return yaml.safe_load(plaintext) or {}
    except subprocess.CalledProcessError as exc:
        raise ValueError(
            f"Failed to decrypt {config_path}: {exc.stderr}"
        ) from exc
    except FileNotFoundError:
        raise ValueError(
            "ansible-vault not found. Install ansible."
        ) from None
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise ValueError(
            f"Failed to decrypt {config_path}: {exc}"
        ) from exc


def _encrypt_vault_file(config_path: str, key_path: str) -> bool:
    """Encrypt file with ansible-vault."""
    try:
        with sensitive_file_descriptor(
            config_path, VAULT_FILE_MODE,
        ) as config_fd, sensitive_file_descriptor(
            key_path, VAULT_FILE_MODE,
        ) as key_fd, atomic_sensitive_output(
            config_path, VAULT_FILE_MODE,
        ) as encrypted_fd:
            run_vault_encrypt(
                config_fd,
                key_fd,
                encrypted_fd,
                timeout=30,
                vault_header=VAULT_HEADER,
            )
    except subprocess.CalledProcessError as exc:
        raise ValueError(
            f"Failed to encrypt {config_path}: {exc.stderr}"
        ) from exc
    except FileNotFoundError:
        raise ValueError(
            "ansible-vault not found. Install ansible."
        ) from None
    except subprocess.TimeoutExpired as exc:
        raise ValueError(
            f"Timed out while encrypting {config_path}"
        ) from exc
    except OSError as exc:
        raise ValueError(
            f"Failed to encrypt {config_path}: {exc}"
        ) from exc
    return True


def load_test_credentials(
    creds_path: Optional[str] = None,
    key_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Load test credentials with automatic vault encryption.

    Args:
        creds_path: Explicit credentials file path.
        key_path: Explicit vault key file path.

    Behavior:
    - Encrypted + key exists: decrypt and return
    - Encrypted + key missing: raise error
    - Plain: read, create key, encrypt, return
    - Not found: return empty dict
    """
    creds_path, key_path = _resolve_credentials_paths(creds_path, key_path)

    if not os.path.lexists(creds_path):
        return {}

    if _is_vault_encrypted(creds_path):
        if os.path.lexists(key_path):
            return _decrypt_vault_file(creds_path, key_path)
        raise ValueError(
            f"Credentials encrypted but key not found: {key_path}"
        )

    with open_sensitive_text(
        creds_path, VAULT_FILE_MODE,
    ) as creds_fh:
        creds = yaml.safe_load(creds_fh) or {}

    if not os.path.lexists(key_path):
        _create_vault_key(key_path)

    _encrypt_vault_file(creds_path, key_path)
    return creds


def encrypt_test_credentials(
    creds_path: Optional[str] = None,
    key_path: Optional[str] = None,
) -> bool:
    """Encrypt credentials file if not already encrypted.

    Args:
        creds_path: Explicit credentials file path.
        key_path: Explicit vault key file path.
    """
    creds_path, key_path = _resolve_credentials_paths(creds_path, key_path)

    if not os.path.lexists(creds_path):
        return False
    if _is_vault_encrypted(creds_path):
        if os.path.lexists(key_path):
            _protect_sensitive_file(key_path)
        return True
    if not os.path.lexists(key_path):
        _create_vault_key(key_path)

    _encrypt_vault_file(creds_path, key_path)
    return True


# =============================================================================
# LOCAL / REMOTE DETECTION
# =============================================================================

def _is_local_ip(ip: str) -> bool:
    """Check if IP belongs to this machine."""
    if ip in ("localhost", "127.0.0.1", ""):
        return True
    try:
        result = subprocess.run(
            ["hostname", "-I"],
            capture_output=True, text=True, timeout=5, check=False,
        )
        return ip in result.stdout.strip().split()
    except (OSError, subprocess.SubprocessError):
        return False


def is_local_execution() -> bool:
    """Determine if tests run locally on the target host.

    Returns True when:
    - oim_server_ip is empty/not set
    - oim_server_ip matches a local IP address
    """
    config = load_test_config()
    oim_ip = config.get("oim_server_ip", "")
    if not oim_ip:
        return True
    return _is_local_ip(str(oim_ip).strip())


# =============================================================================
# TESTINFRA HOST CONNECTION
# =============================================================================

def get_testinfra_host():
    """Get testinfra host connected to the target server.

    When oim_server_ip is empty or local, runs in local mode.
    When oim_server_ip is remote, connects via SSH.

    Returns:
        testinfra Host object.
    """
    config = load_test_config()
    credentials = load_test_credentials()
    oim_ip = str(config.get("oim_server_ip", "")).strip()

    # Local execution
    if not oim_ip or _is_local_ip(oim_ip):
        return testinfra.get_host("local://")

    # Remote — SSH
    ssh_user = config["oim_ssh_user"]
    ssh_port = config.get("oim_ssh_port", 22)
    ssh_auth = credentials.get("oim_password", "")

    ssh_args = get_setting(
        "ssh_opts",
        "-o StrictHostKeyChecking=no "
        "-o UserKnownHostsFile=/dev/null "
        "-o LogLevel=ERROR",
    )

    inventory_path = _write_testinfra_inventory({
        "all": {
            "hosts": {
                "target": {
                    "ansible_host": oim_ip,
                    "ansible_user": ssh_user,
                    "ansible_port": ssh_port,
                    "ansible_ssh_pass": ssh_auth,
                    "ansible_connection": "ssh",
                    "ansible_ssh_common_args": ssh_args,
                },
            },
        },
    })

    return testinfra.get_host(
        "ansible://target", ansible_inventory=inventory_path
    )


def run_on_host(host, cmd: str, *args: str):
    """Run command on the target host (OIM server).

    Args:
        host: Testinfra host object
        cmd: Command template to execute.
        *args: Values that Testinfra must shell-quote into ``%s`` placeholders.

    Returns:
        Result with stdout, stderr, rc attributes.
    """
    return host.run(cmd, *args)


def run_ssh_command(
    host,
    target: str,
    command: str,
    user: str = "root",
    connect_timeout: int = 10,
):
    """Run a passwordless SSH command from the current target host.

    This supports tests that connect to an execution host through testinfra
    and must then inspect a secondary node. Values derived from configuration
    are shell-quoted before the SSH command is passed to testinfra.

    Args:
        host: Current testinfra host object.
        target: Secondary host name or IP address.
        command: Command to execute on the secondary host.
        user: Secondary-host SSH user.
        connect_timeout: SSH connection timeout in seconds.

    Returns:
        Result with stdout, stderr, and rc attributes.

    Raises:
        ValueError: If a required value is empty or timeout is invalid.
    """
    if not isinstance(target, str) or not target.strip():
        raise ValueError("SSH target must be a non-empty string")
    if not isinstance(user, str) or not user.strip():
        raise ValueError("SSH user must be a non-empty string")
    if not isinstance(command, str) or not command.strip():
        raise ValueError("SSH command must be a non-empty string")
    if not isinstance(connect_timeout, int) or connect_timeout <= 0:
        raise ValueError("SSH connect_timeout must be a positive integer")

    ssh_options = get_setting(
        "ssh_opts",
        "-o StrictHostKeyChecking=no "
        "-o UserKnownHostsFile=/dev/null "
        "-o LogLevel=ERROR",
    )
    ssh_command = (
        f"ssh {ssh_options} -o BatchMode=yes "
        f"-o ConnectTimeout={connect_timeout} "
        f"{shlex.quote(f'{user.strip()}@{target.strip()}')} "
        f"{shlex.quote(command)}"
    )
    return run_on_host(host, ssh_command)


# =============================================================================
# MONOREPO HOST UTILITIES
# =============================================================================

_DEFAULT_ENV_FILE = "/etc/omnia/omnia.env"


def connection_params() -> dict:
    """Build mode / ip / user / auth_secret / ssh_opts from test config.

    Returns a dict ready to unpack into ``sync_files()`` or other
    functions that need SSH connection details::

        conn = connection_params()
        sync_files(mode=conn["mode"], ip=conn["ip"], ...)

    Returns:
        Dict with keys: mode, ip, user, auth_secret, ssh_opts.

    Raises:
        ValueError: If required config keys are missing for remote mode.
    """
    config = load_test_config()
    creds = load_test_credentials()
    local = is_local_execution()

    if not local:
        oim_ip = config.get("oim_server_ip", "").strip()
        if not oim_ip:
            raise ValueError(
                "oim_server_ip is required in test_config.yml "
                "for remote (SSH) execution"
            )
        oim_user = config.get("oim_ssh_user", "").strip()
        if not oim_user:
            raise ValueError(
                "oim_ssh_user is required in test_config.yml "
                "for remote (SSH) execution"
            )
    else:
        oim_ip = None
        oim_user = config.get("oim_ssh_user", "root")

    oim_auth = creds.get("oim_password") or None
    return {
        "mode": "local" if local else "ssh",
        "ip": oim_ip,
        "user": oim_user,
        "auth_secret": oim_auth,
        "ssh_opts": get_setting(
            "ssh_opts",
            "-o StrictHostKeyChecking=no "
            "-o UserKnownHostsFile=/dev/null "
            "-o LogLevel=ERROR",
        ),
    }


def read_remote_env(
    host, var_name: str, env_file: str = None
) -> str:
    """Read an environment variable from the target host.

    Sources the env file before reading so that variables defined
    by setup scripts are available in non-login SSH sessions.

    Args:
        host: Testinfra host object.
        var_name: Environment variable name (e.g. ``OMNIA_DATA_PATH``).
        env_file: Path to the env file on the target host.
            Defaults to ``configure(env_file=...)`` or
            ``/etc/omnia/omnia.env``.

    Returns:
        The variable value, stripped.

    Raises:
        ValueError: If the variable is not set or empty on the target.
    """
    ef = env_file or get_setting("env_file", _DEFAULT_ENV_FILE)
    cmd = (
        f"test -f {ef} && set -a && . {ef} && set +a; "
        f"echo ${{{var_name}}}"
    )
    result = host.run(cmd)
    value = result.stdout.strip() if result.rc == 0 else ""
    if not value:
        raise ValueError(
            f"Environment variable '{var_name}' is not set on the "
            f"target host.  Ensure the environment has been set up "
            f"and {ef} contains {var_name}."
        )
    return value


def ensure_remote_dir(host, path: str) -> None:
    """Create a directory on the target if it does not exist.

    Args:
        host: Testinfra host object.
        path: Absolute path to create on the target.

    Raises:
        ValueError: If *path* is empty.
        RuntimeError: If ``mkdir -p`` fails.
    """
    if not path:
        raise ValueError("path is required for ensure_remote_dir")
    result = host.run(f"mkdir -p {path}")
    if result.rc != 0:
        raise RuntimeError(
            f"Failed to create remote directory '{path}': "
            f"{result.stderr.strip()}"
        )
    log(f"Ensured remote directory exists: {path}", "DEBUG")


def read_remote_yaml(host, file_path: str) -> Dict[str, Any]:
    """Read and parse a YAML file from the target host.

    Args:
        host: Testinfra host object.
        file_path: Absolute path to the YAML file on the target.

    Returns:
        Parsed dict, or empty dict on failure.
    """
    result = host.run(f"cat {file_path} 2>/dev/null")
    if result.rc != 0 or not result.stdout.strip():
        return {}
    try:
        return yaml.safe_load(result.stdout) or {}
    except yaml.YAMLError:
        return {}


def read_yaml_key(data: Dict[str, Any], key_path: str, default=None):
    """Read a nested key from a dict using dot-separated path.

    Supports dict keys and list indices (integer path segments).

    Args:
        data: Parsed YAML dict.
        key_path: Dot-separated path (e.g. ``"telemetry_sources.powerscale.metrics_enabled"``).
        default: Value returned when the key is not found.

    Returns:
        The value at the key path, or *default*.

    Examples::

        read_yaml_key(cfg, "telemetry_sources.idrac.metrics_enabled")
        read_yaml_key(cfg, "telemetry_sinks.victoria_metrics")
        read_yaml_key(cfg, "isilonClusters.0.endpoint")
    """
    current = data
    for part in key_path.split("."):
        if current is None:
            return default
        if isinstance(current, dict):
            current = current.get(part)
        elif isinstance(current, list):
            try:
                current = current[int(part)]
            except (ValueError, IndexError):
                return default
        else:
            return default
    return current if current is not None else default


def resolve_domain_input_path(
    host, domain: str, data_path_var: str, project_var: str
) -> str:
    """Build the remote input directory for a domain.

    Reads the given environment variables from the target and
    assembles ``<data_path>/<domain>/input/<project>/``.

    Args:
        host: Testinfra host object.
        domain: Domain name (e.g. ``image_build_manager``).
        data_path_var: Name of the env var holding the data path
            (e.g. ``OMNIA_DATA_PATH``).
        project_var: Name of the env var holding the project name
            (e.g. ``OMNIA_PROJECT_NAME``).

    Returns:
        Absolute path string on the target.

    Raises:
        ValueError: If *domain* is empty or either env var is unset.
    """
    if not domain:
        raise ValueError("domain is required for resolve_domain_input_path")
    data_path = read_remote_env(host, data_path_var)
    project = read_remote_env(host, project_var)
    remote_input = f"{data_path}/{domain}/input/{project}"
    log(f"Resolved remote input path: {remote_input}", "INFO")
    return remote_input


# =========================================================================
# Ansible Inventory Parsing
# =========================================================================

def get_inventory_hosts(
    host,
    inventory_path: str,
    groups: List[str],
    prefix_match: bool = True,
) -> Dict[str, Any]:
    """Get hostnames from specific groups in an Ansible inventory file.

    Parses an Ansible YAML inventory file on the remote host and extracts
    hostnames from the specified groups.

    Args:
        host: Testinfra host object.
        inventory_path: Absolute path to the inventory YAML file.
        groups: List of group names to extract hosts from
            (e.g., ["slurm_control_node", "slurm_node"]).
        prefix_match: If True, match groups that start with the given name
            (e.g., "slurm_node" matches "slurm_node_x86_64"). Default True.

    Returns:
        Dict with keys:
            - success (bool): True if at least one host was found.
            - hostnames (list): All unique hostnames found.
            - by_group (dict): Mapping of matched group name to list of hostnames.
            - error (str): Error message if failed.

    Example::

        result = get_inventory_hosts(
            host,
            "/opt/omnia/telemetry/input/project/orchestrator.yml",
            ["slurm_control_node", "slurm_node"],
        )
        # result["hostnames"] = ["scontrol", "snode1", "snode2"]
        # result["by_group"] = {"slurm_control_node_x86_64": ["scontrol"], ...}
    """
    if not inventory_path:
        return {
            "success": False,
            "hostnames": [],
            "by_group": {},
            "error": "inventory_path is required",
        }

    if not groups:
        return {
            "success": False,
            "hostnames": [],
            "by_group": {},
            "error": "groups list is required",
        }

    # Read and parse the inventory YAML
    inv_data = read_remote_yaml(host, inventory_path)
    if not inv_data:
        return {
            "success": False,
            "hostnames": [],
            "by_group": {},
            "error": f"Failed to read inventory: {inventory_path}",
        }

    # Navigate to all.children in the inventory structure
    all_children = read_yaml_key(inv_data, "all.children", default={})
    if not all_children:
        return {
            "success": False,
            "hostnames": [],
            "by_group": {},
            "error": "No 'all.children' found in inventory",
        }

    by_group = {}
    all_hostnames = []

    for group_pattern in groups:
        # Find matching groups (exact or prefix match)
        matching_groups = []
        for inv_group in all_children.keys():
            if inv_group == group_pattern:
                matching_groups.append(inv_group)
            elif prefix_match and inv_group.startswith(group_pattern + "_"):
                matching_groups.append(inv_group)

        # Extract hosts from matching groups
        for matched_group in matching_groups:
            group_data = all_children[matched_group]
            if isinstance(group_data, dict):
                hosts = group_data.get("hosts", {})
                if isinstance(hosts, dict):
                    hostnames = list(hosts.keys())
                    by_group[matched_group] = hostnames
                    for hostname in hostnames:
                        if hostname not in all_hostnames:
                            all_hostnames.append(hostname)

    return {
        "success": len(all_hostnames) > 0,
        "hostnames": all_hostnames,
        "by_group": by_group,
        "error": "" if all_hostnames else f"No hosts found in groups: {groups}",
    }


def get_inventory_host_var(
    host,
    inventory_path: str,
    group: str,
    hostname: str,
    var_name: str,
    default=None,
):
    """Get a host variable from an Ansible inventory file.

    Args:
        host: Testinfra host object.
        inventory_path: Absolute path to the inventory YAML file.
        group: Group name where the host is defined.
        hostname: Name of the host.
        var_name: Variable name to retrieve (e.g., "ansible_host").
        default: Value to return if not found.

    Returns:
        The variable value or *default* if not found.

    Example::

        ip = get_inventory_host_var(
            host,
            "/opt/omnia/orchestrator.yml",
            "kube_vip_group",
            "kube-vip",
            "ansible_host",
        )
    """
    inv_data = read_remote_yaml(host, inventory_path)
    if not inv_data:
        return default

    key_path = f"all.children.{group}.hosts.{hostname}.{var_name}"
    return read_yaml_key(inv_data, key_path, default=default)
