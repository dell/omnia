# Copyright 2026 Dell Inc. or its subsidiaries. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""omnia-auto — Functions"""

# --- Formatting ---
from .formatting_func import (
    Colors,
    Symbols,
    log,
    set_debug_mode,
    set_verbose_mode,
    TestLogger,
    get_test_output,
    get_last_tc_id,
    get_last_detail_fields,
    clear_test_context,
    add_session_result,
    get_session_results,
    clear_session_results,
    print_summary_table,
)

# --- Host / Config ---
from .host_func import (
    get_testinfra_host,
    load_test_config,
    load_test_credentials,
    run_on_host,
    run_ssh_command,
    is_local_execution,
    encrypt_test_credentials,
    connection_params,
    read_remote_env,
    ensure_remote_dir,
    read_remote_yaml,
    read_yaml_key,
    resolve_domain_data_path,
    resolve_domain_input_path,
    get_inventory_hosts,
    get_inventory_host_var,
)

# --- Report ---
from .report_func import (
    TestReport,
    get_current_report,
    set_current_report,
    build_report_name,
    report_module_name,
    record_playbook_failure,
)

# --- Runner ---
from .runner_func import run_playbook
from .full_playbook_func import run_full_playbook_test

# --- Sync ---
from .sync_func import clone_repo, sync_files

# --- Validation Runner ---
from .validation_runner import ValidationRunner

# --- Credential Management ---
from .credential_func import (
    ensure_vault_key,
    is_vault_encrypted,
    vault_encrypt,
    vault_decrypt_to_dict,
    read_credential_field,
    read_all_fields,
    write_credential_fields,
    prompt_credential,
    prompt_and_confirm,
    prompt_fields_interactive,
)

__all__ = [
    "Colors",
    "Symbols",
    "log",
    "set_debug_mode",
    "set_verbose_mode",
    "TestLogger",
    "get_test_output",
    "get_last_tc_id",
    "get_last_detail_fields",
    "clear_test_context",
    "add_session_result",
    "get_session_results",
    "clear_session_results",
    "print_summary_table",
    "get_testinfra_host",
    "load_test_config",
    "load_test_credentials",
    "run_on_host",
    "run_ssh_command",
    "is_local_execution",
    "encrypt_test_credentials",
    "connection_params",
    "read_remote_env",
    "ensure_remote_dir",
    "read_remote_yaml",
    "read_yaml_key",
    "resolve_domain_data_path",
    "resolve_domain_input_path",
    "get_inventory_hosts",
    "get_inventory_host_var",
    "TestReport",
    "get_current_report",
    "set_current_report",
    "run_playbook",
    "run_full_playbook_test",
    "clone_repo",
    "sync_files",
    "ValidationRunner",
    "ensure_vault_key",
    "is_vault_encrypted",
    "vault_encrypt",
    "vault_decrypt_to_dict",
    "read_credential_field",
    "read_all_fields",
    "write_credential_fields",
    "prompt_credential",
    "prompt_and_confirm",
    "prompt_fields_interactive",
]
