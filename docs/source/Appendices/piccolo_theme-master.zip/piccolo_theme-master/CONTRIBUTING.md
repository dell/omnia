# Contributing

For more details on the ethos and culture behind the Piccolo projects, read the [contributing guidelines from the parent project](https://github.com/piccolo-orm/piccolo/blob/master/CONTRIBUTING.md).

For specific technical details on contributing to this repo, see our [docs](docs/src/contributing.rst).
