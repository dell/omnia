#!/bin/bash
sphinx-autobuild -a docs/src docs/build/html --watch piccolo_theme
