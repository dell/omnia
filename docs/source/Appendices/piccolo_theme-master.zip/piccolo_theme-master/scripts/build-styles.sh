#!/bin/bash
sass --watch src/sass/basic_mod.scss piccolo_theme/static/basic_mod.css
