.. _SupportUs:

Support Us
==========

You can help us in many ways:

* Sharing the project with others
* Leaving `feedback <https://github.com/piccolo-orm/piccolo_theme/discussions>`_
* Starring the repo on `GitHub <https://github.com/piccolo-orm/piccolo_theme>`_
* Making improvements to the theme by making a `pull request <https://github.com/piccolo-orm/piccolo_theme>`_
* Buying our `book about documentation and Sphinx <https://piccolo-store.com/books/mastering-docs/>`_

Thanks! 🙏
