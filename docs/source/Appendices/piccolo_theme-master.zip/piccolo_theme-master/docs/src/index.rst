Piccolo Theme
=============

A clean and modern theme for `Sphinx <https://www.sphinx-doc.org/en/master/>`_.

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   ./setup.rst
   ./configuration.rst
   ./help.rst
   ./support_us.rst
   ./about.rst
   ./contributing.rst
   ./demo.rst
   ./changes.rst
