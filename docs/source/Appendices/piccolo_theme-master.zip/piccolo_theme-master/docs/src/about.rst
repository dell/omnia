About
=====

This theme was created to document `Piccolo <https://github.com/piccolo-orm/piccolo>`_
and sister projects.

Here's a live example of it being used:

* https://piccolo-orm.readthedocs.io/en/latest/
